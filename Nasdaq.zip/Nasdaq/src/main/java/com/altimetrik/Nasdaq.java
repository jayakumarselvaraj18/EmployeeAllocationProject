package com.altimetrik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nasdaq {

	public static void main(String[] args) {
		SpringApplication.run(Nasdaq.class, args);
	}

}
