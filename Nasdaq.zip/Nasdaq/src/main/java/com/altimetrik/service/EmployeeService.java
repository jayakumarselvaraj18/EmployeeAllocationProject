package com.altimetrik.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.model.Employee;
import com.altimetrik.model.Project;
import com.altimetrik.repo.EmployeeRepo;
import com.altimetrik.repo.ProjectRepo;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;

	@Autowired
	ProjectRepo projectRepo;

	@Autowired
	EmailService emailService;

	public Employee saveEmployee(Employee employee) {
		return employeeRepo.save(employee);
	}

	public void allocateProjectToEmployee(Long employeeId, String projectName, float allocation) {

		if (projectName == null || projectName.isEmpty()) {
			throw new RuntimeException("Project name cannot be null or empty");
		}
		// 1. Find the employee
		Employee employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new RuntimeException("Employee not found"));

		// 2. Find the project by projectName
		Project project = projectRepo.findByProjectName(projectName)
				.orElseThrow(() -> new RuntimeException("Project not found"));

		// 3. Set allocation to employee (project allocation might be stored in
		// employee)
		employee.setProject(project);
		employee.setProjectAllocation(allocation); // Allocating to the employee

		// 4. Save the updated employee record
		employeeRepo.save(employee);

		// 5. Send email notification about the allocation
		String subject = "Project Allocation Notification";
		String message = "You have been successfully allocated to the project:"; 
		// Send the email
		emailService.sendEmail(employee.getEmail(), subject, message);
	}

	// Method to update the project allocation of an employee
	public Employee updateProjectAllocation(Long employeeId, String projectName, float newAllocation) {
		// Find the employee by ID
		Employee employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new RuntimeException("Employee not found"));

		// Ensure the allocation is within the valid range
		if (newAllocation < 0.1f || newAllocation > 1.0f) {
			throw new IllegalArgumentException("Allocation must be between 0.1 and 1.0");
		}

		// Find the project by name
		Project project = projectRepo.findByProjectName(projectName)
				.orElseThrow(() -> new RuntimeException("Project not found"));

		// Check if the employee is already assigned to this project
		if (employee.getProject() != null && !employee.getProject().getProjectName().equals(projectName)) {
			throw new RuntimeException("This employee is not assigned to the specified project");
		}

		// Update the project allocation
		employee.setProject(project);
		employee.setProjectAllocation(newAllocation);

		// Save the updated employee record
		return employeeRepo.save(employee);
	}

	public List<Employee> getEmployeesBySkills(String primarySkill, String secondarySkill) {
		return employeeRepo.findEmployeesBySkills(primarySkill, secondarySkill);
	}

	public Employee getSecondMostExperiencedEmployee(Long projectId) {
		// Get the list of employees sorted by experience
		List<Employee> employees = employeeRepo.findEmployeesByProjectId(projectId);

		// If there are less than 2 employees, return null or throw exception
		if (employees == null || employees.size() < 2) {
			throw new RuntimeException("Not enough employees in the project to determine the 2nd most experienced.");
		}

		// Return the second employee (index 1) in the sorted list
		return employees.get(1);
	}

	public List<Employee> getEmployeesWithoutPrimarySkill(String primarySkill) {
		return employeeRepo.findEmployeesWithoutPrimarySkill(primarySkill);
	}
}
