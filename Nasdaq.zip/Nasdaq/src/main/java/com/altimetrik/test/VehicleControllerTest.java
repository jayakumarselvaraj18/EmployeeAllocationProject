package com.altimetrik.test;



public class VehicleControllerTest {
	
	

}
