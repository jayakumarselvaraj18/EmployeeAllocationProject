package com.altimetrik.enumclass;

public enum Designation {
	PRINCIPAL_ENGINEER,
    STAFF_ENGINEER,
    TECHNICAL_LEAD,
    ARCHITECT,
    SENIOR_ENGINEER,
    ENGINEER,
    ASSOC_ENGINEER;
}
