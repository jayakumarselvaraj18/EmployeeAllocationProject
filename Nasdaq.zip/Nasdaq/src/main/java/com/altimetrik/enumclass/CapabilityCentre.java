package com.altimetrik.enumclass;

public enum CapabilityCentre {
	PRODUCT_AND_PLATFORM,
    DEP_CLOUD,
    DEVAA,
    DEP_QUALITY;
}
