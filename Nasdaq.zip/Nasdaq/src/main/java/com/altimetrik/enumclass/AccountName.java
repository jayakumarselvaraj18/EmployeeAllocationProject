package com.altimetrik.enumclass;

public enum AccountName {
    ANCESTRY,
    BNYM,
    CALIBO_LLC,
    EXPERIAN,
    FORD,
    GUARANTEED_RATE,
    INVOICE_CLOUD,
    VATTIKUTI_VENTURES_LLC,
    ZIP_CO_US_INC,
    PAYPAL,
    JOHNSON_CONTROLS_INC,
    WESTERN_UNION;
}
